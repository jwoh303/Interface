/*
 * Copyright 2015-2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package com.amazonaws.services.timestreamquery.model;

import java.io.Serializable;
import javax.annotation.Generated;

import com.amazonaws.AmazonWebServiceRequest;

/**
 * 
 * @see <a href="http://docs.aws.amazon.com/goto/WebAPI/timestream-query-2018-11-01/CancelQuery" target="_top">AWS API
 *      Documentation</a>
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class CancelQueryRequest extends com.amazonaws.AmazonWebServiceRequest implements Serializable, Cloneable {

    /**
     * <p>
     * The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     * </p>
     */
    private String queryId;

    /**
     * <p>
     * The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     * </p>
     * 
     * @param queryId
     *        The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     */

    public void setQueryId(String queryId) {
        this.queryId = queryId;
    }

    /**
     * <p>
     * The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     * </p>
     * 
     * @return The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     */

    public String getQueryId() {
        return this.queryId;
    }

    /**
     * <p>
     * The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     * </p>
     * 
     * @param queryId
     *        The id of the query that needs to be cancelled. <code>QueryID</code> is returned as part of QueryResult.
     * @return Returns a reference to this object so that method calls can be chained together.
     */

    public CancelQueryRequest withQueryId(String queryId) {
        setQueryId(queryId);
        return this;
    }

    /**
     * Returns a string representation of this object. This is useful for testing and debugging. Sensitive data will be
     * redacted from this string using a placeholder value.
     *
     * @return A string representation of this object.
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        if (getQueryId() != null)
            sb.append("QueryId: ").append(getQueryId());
        sb.append("}");
        return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;

        if (obj instanceof CancelQueryRequest == false)
            return false;
        CancelQueryRequest other = (CancelQueryRequest) obj;
        if (other.getQueryId() == null ^ this.getQueryId() == null)
            return false;
        if (other.getQueryId() != null && other.getQueryId().equals(this.getQueryId()) == false)
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hashCode = 1;

        hashCode = prime * hashCode + ((getQueryId() == null) ? 0 : getQueryId().hashCode());
        return hashCode;
    }

    @Override
    public CancelQueryRequest clone() {
        return (CancelQueryRequest) super.clone();
    }

}
